package com.example.smartalarmsystem;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class clockSetting extends AppCompatActivity
{
    MediaPlayer mediaPlayer;
    TimePicker timePicker;
    int aid=0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clock_setting);
        timePicker = (TimePicker)findViewById(R.id.timePicker);
        timePicker.setIs24HourView(true);

        Spinner spinner = (Spinner)findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                    switch (position) {
                        case 0:
                            break;
                        case 1:
                            mediaPlayer = MediaPlayer.create(clockSetting.this, R.raw.tone1);
                            mediaPlayer.start();
                            new CountDownTimer(2000, 1000) {
                                @Override
                                public void onTick(long millisUntilFinished) {
                                }

                                @Override
                                public void onFinish() {
                                    mediaPlayer.stop();
                                }
                            }.start();
                            break;
                        case 2:
                            mediaPlayer = MediaPlayer.create(clockSetting.this, R.raw.tone2);
                            mediaPlayer.start();
                            new CountDownTimer(2000, 1000) {
                                @Override
                                public void onTick(long millisUntilFinished) {
                                }

                                @Override
                                public void onFinish() {
                                    mediaPlayer.stop();
                                }
                            }.start();
                            break;
                        case 3:
                            mediaPlayer = MediaPlayer.create(clockSetting.this, R.raw.tone3);
                            mediaPlayer.start();
                            new CountDownTimer(2000, 1000) {
                                @Override
                                public void onTick(long millisUntilFinished) {
                                }

                                @Override
                                public void onFinish() {
                                    mediaPlayer.stop();
                                }
                            }.start();
                            break;
                        case 4:
                            mediaPlayer = MediaPlayer.create(clockSetting.this, R.raw.tone4);
                            mediaPlayer.start();
                            new CountDownTimer(2000, 1000) {
                                @Override
                                public void onTick(long millisUntilFinished) {
                                }

                                @Override
                                public void onFinish() {
                                    mediaPlayer.stop();
                                }
                            }.start();
                            break;
                        case 5:
                            mediaPlayer = MediaPlayer.create(clockSetting.this, R.raw.tone5);
                            mediaPlayer.start();
                            new CountDownTimer(2000, 1000) {
                                @Override
                                public void onTick(long millisUntilFinished) {
                                }

                                @Override
                                public void onFinish() {
                                    mediaPlayer.stop();
                                }
                            }.start();
                            break;
                    }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });

    }

    public void cancel_alarm(View v)
    {
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void set_alarm(View v)
    {
        Spinner spinner = (Spinner)findViewById(R.id.spinner);
        switch (spinner.getSelectedItemPosition())
        {
            case 0:
                mediaPlayer = MediaPlayer.create(this,R.raw.tone1);
                break;
            case 1:
                mediaPlayer = MediaPlayer.create(this,R.raw.tone2);
                break;
            case 2:
                mediaPlayer = MediaPlayer.create(this,R.raw.tone3);
                break;
            case 3:
                mediaPlayer = MediaPlayer.create(this,R.raw.tone4);
                break;
            case 4:
                mediaPlayer = MediaPlayer.create(this,R.raw.tone5);
                break;
        }
        mediaPlayer.setLooping(true);

        EditText editText = (EditText)findViewById(R.id.alarmName);
        timePicker = (TimePicker)findViewById(R.id.timePicker);

        String str = String.valueOf(timePicker.getHour())+":"+String.valueOf(timePicker.getMinute())+" "+editText.getText().toString();

        Intent alarmN = new Intent(getApplicationContext(), MainActivity.class);
        alarmN.putExtra("alarm_name", str);
        startActivity(alarmN);

        int h = timePicker.getHour();
        int m = timePicker.getMinute();
        int sec=0;

        Date time = Calendar.getInstance().getTime();
        h = h - time.getHours();
        m = m - time.getMinutes();
        sec = sec - time.getSeconds();

        if(sec<0)
        {
            sec = sec +60;
            m--;
        }
        if(m<0)
        {
            m = 60+m;
            h--;
        }
        final int milis = (h*3600+m*60+sec)*1000;
        new CountDownTimer(milis,1000)
        {

            @Override
            public void onTick(long millisUntilFinished) {
            }
            @Override
            public void onFinish()
            {
                mediaPlayer.start();
                Intent st_name = new Intent(getApplicationContext(), solve.class);
                st_name.putExtra("stop_alarm",mediaPlayer.getAudioSessionId());
                startActivity(st_name);
            }
        }.start();

        Toast.makeText(this,"Alarm after: "+h+" HH "+m+" MM "+sec+" SS",Toast.LENGTH_LONG).show();
    }

}