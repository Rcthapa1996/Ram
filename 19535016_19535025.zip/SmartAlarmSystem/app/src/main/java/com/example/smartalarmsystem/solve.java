package com.example.smartalarmsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class solve extends AppCompatActivity {

    TextView tx1;
    TextView tx2;
    TextView tx3;
    EditText ans;
    List<Integer> givenList1 = Arrays.asList(0,1,2,3,4,5,6,7,8,9);
    List<String> givenList2= Arrays.asList("+","-","*");

    public void randata()
    {
        Random rand1 = new Random();
        tx1.setText(String.valueOf(givenList1.get(rand1.nextInt(givenList1.size()))));


        Random rand2 = new Random();
        tx2.setText(String.valueOf(givenList2.get(rand2.nextInt(givenList2.size()))));

        Random rand3 = new Random();
        tx3.setText(String.valueOf(givenList1.get(rand3.nextInt(givenList1.size()))));

    }

    public void submit_ans(View v)
    {
        int i = 0;

        if(tx2.getText().toString().compareTo("+")==0)
        {
            if(Integer.parseInt(tx1.getText().toString())+Integer.parseInt(tx3.getText().toString()) == Integer.parseInt(ans.getText().toString()))
                i = 1;
        }
        else if(tx2.getText().toString().compareTo("-")==0)
        {
            if (Integer.parseInt(tx1.getText().toString()) - Integer.parseInt(tx3.getText().toString()) == Integer.parseInt(ans.getText().toString()))
                i = 1;
        }
        else
        {
            if(Integer.parseInt(tx1.getText().toString())*Integer.parseInt(tx3.getText().toString()) == Integer.parseInt(ans.getText().toString()))
                i = 1;
        }

        if(i==1)
        {
            MediaPlayer mp;
            Intent intent = getIntent();
            String str = intent.getStringExtra("stop_alarm");

            switch (str)
            {
                case "tone1":
                    mp = MediaPlayer.create(this,R.raw.tone1);
                    mp.stop();
                    break;
                case "tone2":
                    mp = MediaPlayer.create(this,R.raw.tone2);
                    mp.stop();
                    break;
                case "tone3":
                    mp = MediaPlayer.create(this,R.raw.tone3);
                    mp.stop();
                    break;
                case "tone4":
                    mp = MediaPlayer.create(this,R.raw.tone4);
                    mp.stop();
                    break;
                case "tone5":
                    mp = MediaPlayer.create(this,R.raw.tone5);
                    mp.stop();
                    break;
            }
        }
        else
        {
            Toast.makeText(this,"Wrong answer please try again",Toast.LENGTH_LONG).show();
            randata();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solve);
        tx1 =(TextView)findViewById(R.id.arith1);
        tx2 =(TextView)findViewById(R.id.arith2);
        tx3 =(TextView)findViewById(R.id.arith3);
        ans = (EditText)findViewById(R.id.ans);

        randata();

    }
}
